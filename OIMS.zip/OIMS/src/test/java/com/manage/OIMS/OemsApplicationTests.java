package com.manage.OIMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OemsApplicationTests {

	@Test
	void contextLoads() {
	}

}
